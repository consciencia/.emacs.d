#pragma once

#include "Util.h"

//
// This files shows use of the namespaces in Util.hh but with diff symbols.
//
namespace play { namespace prod {
class Manager {
   public:
   explicit Manager(const int);
};
}}


// Generic src file for CMake.

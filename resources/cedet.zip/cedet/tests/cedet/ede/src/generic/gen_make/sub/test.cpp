// C file in generic project.

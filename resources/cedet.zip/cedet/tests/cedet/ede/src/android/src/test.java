/* Test Java File in a subdirectory */

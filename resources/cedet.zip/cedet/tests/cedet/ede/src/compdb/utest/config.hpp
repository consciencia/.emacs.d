#ifndef CONFIG_HPP
#define CONFIG_HPP

#define HELLO_BAR HelloBar

#endif

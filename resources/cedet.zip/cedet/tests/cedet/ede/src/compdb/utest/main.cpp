#include "world.hpp"
#include <iostream>

void HELLO_FOO();
void HELLO_BAR();
void HELLO_BAZ();

int main()
{
    HelloWorld(std::cout);
    return 0;
}
